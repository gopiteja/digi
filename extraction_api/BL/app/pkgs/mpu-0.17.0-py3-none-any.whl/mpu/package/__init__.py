import mpu.package.cli  # noqa
